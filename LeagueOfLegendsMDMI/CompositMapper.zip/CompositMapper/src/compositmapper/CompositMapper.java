/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compositmapper;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author maksim
 */
public class CompositMapper {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        if(args.length == 0) {
            System.out.println("Provide champion item sets file.");
            System.exit(0);
        } else {
            if(args.length==1) System.exit(1);
        }
        CSVReader reader = new CSVReader(new BufferedReader(new FileReader("items.csv")),',');
        List<String[]> data =  reader.readAll();
        HashMap<String, Boolean> items = new HashMap();
        for(int i=1; i<data.size();i++){
            //System.out.println(arr[13] + " "+ arr[20]);
            String id = data.get(i)[36].trim();
           // System.out.println(id);
            Boolean b = false;
            String[] complexity = data.get(i)[13].split(",");
            //System.out.println(Arrays.toString(complexity) + " "+complexity.length);
            if(complexity.length < 2) b = true;
            items.put(id, b);
        }
        reader = new CSVReader(new BufferedReader(new FileReader(new File(args[0]))),';');
        
        List<String[]> chempData = reader.readAll();
        //System.out.println(Arrays.toString(chempData.get(chempData.size()-1)));
        //chempData.forEach(x -> System.out.println(Arrays.toString(x)));
        //items.entrySet().stream().forEach(System.out::println);
        for(int i=1; i<chempData.size();i++){
            //System.out.println(Arrays.toString(s));
            for(int j = 0; j < chempData.get(i).length; j++){
         //       System.out.println(chempData.get(i)[j]);
                Boolean key = items.get(chempData.get(i)[j]);
                if(key != null)
                    if(key){chempData.get(i)[j]="";}
            }
        }
       // System.out.println(items.get("Corrupting Potion") + " ------------------------");
        writeItems(args[1], chempData);
        
    }
    static public void writeItems(String fileName,List<String[]> data){
        try{
            BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
            CSVWriter writer = new CSVWriter(out, ',');
            
            String[] t=new String[0];
            for(String[] row : data){

                writer.writeNext(row);
            }
            out.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }   
    }
   
    
}
